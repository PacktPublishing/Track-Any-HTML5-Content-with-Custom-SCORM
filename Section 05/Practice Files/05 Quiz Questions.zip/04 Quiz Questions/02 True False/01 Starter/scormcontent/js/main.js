// Get Radio Buttons
let optionA = document.getElementById('optionA');
let optionB = document.getElementById('optionB');
let optionC = document.getElementById('optionC');
let optionD = document.getElementById('optionD');

// Feedback areas
let correctFeedback = document.getElementById('correctFeedback');
let incorrectFeedback = document.getElementById('incorrectFeedback');
let displayArea = document.getElementById('displayArea');

// Submit question
function submitQuestion(){
	if (optionA.checked) {
		showFeedback('correct');
	} else if (optionB.checked){
		showFeedback('incorrect');
	}
}

function showFeedback(result){
	// Show display area
	displayArea.classList.remove('d-none');
	// Show correct or incorrect
	if (result == 'correct') {
		correctFeedback.classList.add('d-none');
		incorrectFeedback.classList.remove('d-none');
	} else{
		incorrectFeedback.classList.add('d-none');
		correctFeedback.classList.remove('d-none');
	}
}

