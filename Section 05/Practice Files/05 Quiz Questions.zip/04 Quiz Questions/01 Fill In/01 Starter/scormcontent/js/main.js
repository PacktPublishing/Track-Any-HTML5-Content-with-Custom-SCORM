// Get Radio Buttons
let questionResponse = document.getElementById('questionResponse');

// Feedback areas
let correctFeedback = document.getElementById('correctFeedback');
let incorrectFeedback = document.getElementById('incorrectFeedback');
let displayArea = document.getElementById('displayArea');

// Submit question
function submitQuestion(){
	if (questionResponse.value == "blue") {
		showFeedback('correct');
	} else {
		showFeedback('incorrect');
	}
}

function showFeedback(result){
	// Show display area
	displayArea.classList.remove('d-none');
	// Show correct or incorrect
	if (result == 'correct') {
		correctFeedback.classList.add('d-none');
		incorrectFeedback.classList.remove('d-none');
	} else{
		incorrectFeedback.classList.add('d-none');
		correctFeedback.classList.remove('d-none');
	}
}

