// SCORM Parent
let SD = window.parent;

// Elements
let displayTime = document.getElementById('displayTime');
let displayStatus = document.getElementById('displayStatus');
let displayPassed = document.getElementById('displayPassed');
let displayFailed = document.getElementById('displayFailed');
let displayReset = document.getElementById('displayReset');
let displaySuspendData = document.getElementById('displaySuspendData');
let scormData = document.getElementById('setScormData');
let scormScore = document.getElementById('setScormScore');

// Get Time
function getTime(){
	displayTime.innerHTML = "Total time spent in course: <strong>" + getOverallTime() + "</strong><br/>Time spent this session: <strong>" + getSessionTime() + "</strong>";
}

// Get Status
function getStatus(){
	displayStatus.innerHTML = decodeStatus(SD.GetStatus());
}

// Set Passed
function setPassed(){
	SD.SetPassed();
	displayPassed.innerHTML = "Course is now passed";
}

// Set Failed
function setFailed(){
	SD.SetFailed();
	displayFailed.innerHTML = "Course is now set to failed";
}

// Reset Status
function resetStatus(){
	SD.ResetStatus();
	displayReset.innerHTML = "Course status has now been reset.";
}

// Set Suspend Data
function setSuspendData(){
	SD.SetDataChunk(scormData.value);
}

// Get Suspend Data
function getSuspendData(){
	displaySuspendData.innerHTML = SD.GetDataChunk();
}



// Get Overall Time
function getOverallTime(){
	var millisecondsOverall = SD.GetSessionAccumulatedTime() + SD.GetPreviouslyAccumulatedTime();
	var timeSpentOverall = "";
	timeSpentOverall += Math.round((millisecondsOverall / (1000*60*60)) % 24)+' hours, ';
	timeSpentOverall += Math.round((millisecondsOverall / (1000*60)) % 60)+' minutes, ';
	timeSpentOverall += Math.round((millisecondsOverall / 1000) % 60)+' seconds.';
	return timeSpentOverall;
}

function getSessionTime(){
	var millisecondsSession = SD.GetSessionAccumulatedTime();
    var timeSpentSession = "";
    timeSpentSession += Math.round((millisecondsSession / (1000*60*60)) % 24)+' hours, ';
    timeSpentSession += Math.round((millisecondsSession / (1000*60)) % 60)+' minutes, ';
    timeSpentSession += Math.round((millisecondsSession / 1000) % 60)+' seconds.';
    return timeSpentSession;
}

// Decode the number
function decodeStatus(intStatus){
	var stringStatus = "";
	switch(intStatus){
		case 1:
			stringStatus = "Passed";
			break;
		case 2:
			stringStatus = "Incomplete";
			break;
		case 3:
			stringStatus = "Failed";
			break;
		case 4: 
			stringStatus = "Unknown / Not Set";
			break;
		default:
			break;
	}
	return stringStatus;
}