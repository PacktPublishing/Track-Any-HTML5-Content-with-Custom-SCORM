// SCORM Parent
let SD = window.parent;

// Elements
let displayTime = document.getElementById('displayTime');
let displayStatus = document.getElementById('displayStatus');
let displayPassed = document.getElementById('displayPassed');
let displayFailed = document.getElementById('displayFailed');
let displayReset = document.getElementById('displayReset');
let displaySuspendData = document.getElementById('displaySuspendData');